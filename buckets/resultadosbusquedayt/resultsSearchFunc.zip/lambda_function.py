import json
import logging
import subprocess

import boto3
import uuid
import os
import sys
import pymysql
from urllib.parse import unquote_plus

rds_host = "yourEC2InstanceIP"

username = "admin"
password ="password"
dbname = "youtube"

try:
    conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
except pymysql.MySQLError as e:
    print (e)
    sys.exit()
    
def lambda_handler(event, context):
    print(str(event))
    result=0;
    resultadosBD = 0;
    redirectPage="";
    isCorrect = 0;
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        busqueda = record['s3']['object']['key']
        
        try:
             videoslist = [];
             with conn.cursor() as cur:
                   cur.execute("SELECT tagsbusq,filepath FROM videos WHERE tagsbusq ='" + busqueda +"'")
                   resultadosBD = cur.fetchall()
                   tbl = "<tr><td><h1>Resultados de la busqueda</h1></td></tr>"
                   videoslist.append(tbl)
                   for row in resultadosBD:
                      a = '<tr><td><a href=%s>%s</a></td></tr>'%(row[1], row[0])
                      videoslist.append(a)
                   
                   msg='''<!DOCTYPE html>
                   <html>
                   <head>
                   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                   <title>Resultados busqueda</title>
                   </head>
                   <body>
                   <table>%s</table>
                   </body>
                   </html>
                   '''%(videoslist);
                   
                   encoded_string = msg.encode("utf-8")
                   file_name = "resultsSearch.html"
                   s3 = boto3.resource("s3")
                   s3.Bucket(bucket).put_object(Key=file_name, Body=encoded_string,ContentType='text/html')
                   object_acl = s3.ObjectAcl(bucket,file_name)
                   object_acl.put(ACL   = 'public-read')
        except pymysql.MySQLError as e:
            print (e)
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body':json.dumps({ 'output' :  'ok' })
    }


