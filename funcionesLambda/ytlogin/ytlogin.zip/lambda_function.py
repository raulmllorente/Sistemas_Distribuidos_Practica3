import sys
import logging
import pymysql
import json
import hashlib

rds_host = "yourEC2InstanceIP"

username = "admin"
password ="password"
dbname = "youtube"

try:
    conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
except pymysql.MySQLError as e:
    print (e)
    sys.exit()

def lambda_handler(event , context):
    username=event["queryStringParameters"]["username"];
    passwd=event["queryStringParameters"]["passwd"];
    result=0;
    resultadosBD = 0;
    redirectPage="";
    isCorrect = 0;


    try:
        colaUsuariosCheck = [];
        hashPasswd = hashlib.md5(passwd.encode())
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM usuarios WHERE username ='" +username + "' AND passwd ='" + hashPasswd.hexdigest() +"'")
            resultadosBD = cur.fetchall()

            for row in resultadosBD:
                for x in row:
                    colaUsuariosCheck.append(x)

            if (username and hashPasswd.hexdigest()) in colaUsuariosCheck:
                redirectPage="http://" +rds_host+ "/home.html";
            else:
                print('No existe usuario o credenciales incorrectas')
                redirectPage="http://" +rds_host+ "/ytlogin.html";
    except pymysql.MySQLError as e:
        print (e)
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : json.dumps( {'redirect': redirectPage} )
    }
